<?php
include('../config/class.php');
$dbclass = new Databases();
// POSTAPI
if ($_POST['action'] == 'saveAPI') {
    $name = mysqli_real_escape_string($dbclass->con, $_POST['name']);
    $email = mysqli_real_escape_string($dbclass->con, $_POST['email']);
    $ipaddress = mysqli_real_escape_string($dbclass->con, $_POST['ipaddress']);

    $insert = array(
        //fieldname => parameter
        'name'   =>  $name,
        'email'   =>  $email,
        'ipaddress'   =>  $ipaddress,
    );

    $dbclass->insert("tbl_users", $insert);

}

//getAPI returns of all the user
elseif ($_POST['action'] == 'returnAll_user') {
    $dbclass->select("tbl_users");
    echo json_encode(array("msg" => "All data Fetch!", "bool" => true));
}

//getAPI
elseif ($_POST['action'] == 'return_userid') {

    $id = $_GET['userid'];
    $where    = array(
        "id"   =>  $id
    );
    if (isset($id)) {
        $dbclass->select_where("tbl_users", $where);
        echo json_encode(array("msg" => "Searching,done!", "bool" => true));
    }
    else {
        echo json_encode(array("msg" => "Text must not Empty!", "bool" => false));
    }
}

?>
