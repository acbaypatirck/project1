<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | Top Navigation</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@700&display=swap" rel="stylesheet">
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../resources/css/adminlte.min.css">
</head>
<style>
  body {
    font-family: Poppins;
    font-weight: 700;
}
.btn-color-light-blue{
  background-color:#e5edff;
} 
.btn-color-blue{
  background-color:#0058ff;
} 
.gray{
  color:#6b7280;
} 
.blue{
  color:#0058ff;
} 
</style>
<body class="hold-transition layout-top-nav">
<div class="wrapper">


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <div class="content">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 mt-5 pt-5" >
              <!-- <div class="row">
                <h1 style="font-size:55px">Enter a data<div style="color:blue;font-size:55px;">offshore business</div></h1>
              
              </div>
              <div class="row">
                <div class="col-lg-10">
                 <p class="gray">Anim aute id magna aliqua ad ad non deserunt sunt. Qui irure qui lorem cupidatat commodo. Elit sunt amet fugiat veniam occaecat fugiat aliqua.</p>
                </div>
              </div>  -->
                    <div class="col-md-2">
                        <div class="form-group m-8">
                            <label for="exampleInputEmail1">Name</label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group m-8">
                        <input type="text" class="form-control form-control-sm gen_txt" id="name" placeholder="Enter Name">
                        </div>
                    </div>
                    <!-- <div class="col-md-5"></div> --->
                    <div class="col-md-2">
                        <div class="form-group m-8">
                            <label for="exampleInputEmail1">Email</label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group m-8">
                            <input type="text" class="form-control form-control-sm gen_txt" id="email" placeholder="Enter email">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group m-8">
                            <label for="exampleInputEmail1">IP Address</label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group m-8">
                            <input type="number" class="form-control form-control-sm gen_txt" id="ipaddress" placeholder="Enter ip addres">
                        </div>
                    </div>


                <a href="#" class="btn btn-primary">Submit</a>
           
          
          </div>
        </div>
        <!-- /.row -->
      </div>
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->


  <!-- <footer class="main-footer">
    <div class="float-right d-none d-sm-inline">
      Anything you want
    </div>
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
  </footer> -->
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../resources/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../resources/js/demo.js"></script>
<script>
      $('#save_btn').click(function() {

        $.ajax({
          url: "../../api/API.php",
          method: "post",
          dataType: "json",
          data: {
              name: $("#name").val(),
              email: $("#email").val(),
              ipaddress: $("#ipaddress").val(),
              action: "saveAPI"
          },
          success: function(data) {
              console.log(data);
          },
          error: function(error) {
              console.log(error);
          }
      })
    });
</script>
</body>
</html>
