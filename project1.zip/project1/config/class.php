<?php

class Databases
{
    public $con;
    public function __construct()
    {
        $this->con = new mysqli("localhost", "root", "", "database_test");
        if (!$this->con) {
            die("Connection error:" . $this->con->connect_error);
        }
        mysqli_query($this->con, "SET NAMES 'utf8', SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'");
    }
    public function insert($table_name, $data)
    {
        $keys = implode(":::", array_values($data));
        $ex = explode(":::", $keys);
        $clause = implode(',', array_fill(0, count($data), '?'));
        $bindString = str_repeat('s', count($data));
        $string = "INSERT INTO " . $table_name . ' (' .  implode(",", array_keys($data)) . ") VALUES ";
        $string .= "(" . $clause . ")";
     
        $stmt = $this->con->prepare($string);
        $stmt->bind_param($bindString, ...$ex);
        if ($stmt->execute()) {
            return true;
        } else {
            echo mysqli_error($this->con);
        }
    }
    public function select($table_name)
    {
        $array = array();
        //$query = $table_name;
        $query = "SELECT * FROM " . $table_name;
        $result = mysqli_query($this->con, $query);
        while ($row = mysqli_fetch_assoc($result)) {
            $array[] = $row;
        }
        return $array;
    }

    public function select_where($table_name, $where_condition)
    {
        $condition = '';
        $array = array();
        foreach ($where_condition as $key => $value) {
            $condition .= $key . " = '" . mysqli_real_escape_string($this->con, $value) . "' AND ";
        }
        $condition = substr($condition, 0, -5);
        $query = "SELECT * FROM " . $table_name . " WHERE " . $condition;
        $result = mysqli_query($this->con, $query);
        while ($row = mysqli_fetch_array($result)) {
            $array[] = $row;
        }
        return $array;
    }

}
